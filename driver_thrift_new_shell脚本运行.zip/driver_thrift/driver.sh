#!/bin/bash

thrift=`ps -ef | grep thrift_test |grep -v grep |awk '{print $2}'`
driver=`ps -ef | grep  driver_operateOrder |grep -v grep |awk '{print $2}'`
order=`ps -ef | grep  creatOrder |grep -v grep |awk '{print $2}'`

#echo "检查踩点服务thrift_testevn.jar是否启动"
if [ ! -n "$thrift" ]; then  
      echo "启动 踩点thrift_test 脚本"
        nohup java -jar thrift_testevn.jar  >/dev/null 2>&1  &  
    else  
          echo "踩点服务thrift_testevn.jar已经启动"  
      fi  
      sleep 1
#echo "检查司机端接单服务driverOrder_testevn.jar是否启动"
      if [ ! -n "$driver" ]; then  
            echo "启动 接单driverOrder_testevn.jar 脚本"
              nohup java -jar driverOrder_testevn.jar  >/dev/null 2>&1  &
          else  
                echo "接单服务driverOrder_testevn.jar已经启动"  
            fi 
            
#echo "检查创建订单服务creatOrder_testevn.jar是否启动"
      if [ ! -n "$order" ]; then  
            echo "启动 创建订单creatOrder 脚本"
              nohup java -jar creatOrder_testevn.jar  >/dev/null 2>&1  &
          else  
                echo "创建订单服务creatOrder_testevn.jar已经启动"  
            fi            
