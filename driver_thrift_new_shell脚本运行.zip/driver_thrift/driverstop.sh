#!/bin/bash
thrift=`ps -ef | grep thrift_test |grep -v grep |awk '{print $2}'`
driver=`ps -ef | grep  driver_operateOrder |grep -v grep |awk '{print $2}'`
order=`ps -ef | grep  creatOrder |grep -v grep |awk '{print $2}'`

#echo $thrift
#echo $driver
#echo $order

if [ ! -n "$order" ]; then   
    echo "创建订单服务createOrder 未启动"
else  
     echo "停止 创建订单createOrder 进程"
     ps -ef|grep createOrder |grep -v grep |awk '{print $2}' | xargs kill -9
    
fi
sleep 1
if [ ! -n "$thrift" ]; then  
    echo "踩点服务thrift_test未启动"
else  
    echo "停止 司机端踩点thrift_test 进程"
    ps -ef | grep thrift_test |grep -v grep |awk '{print $2}'| xargs kill -9  
fi 
sleep 1
if [ ! -n "$driver" ]; then   
    echo "司机端接单服务driver_opertaeOrder 未启动"
else  
     echo "停止 司机端接单driver_opertaeOrder 进程"
     ps -ef|grep driver_operateOrder |grep -v grep |awk '{print $2}' | xargs kill -9
    
fi
