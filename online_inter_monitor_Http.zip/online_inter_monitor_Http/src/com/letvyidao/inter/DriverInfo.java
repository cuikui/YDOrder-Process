package com.letvyidao.inter;

public class DriverInfo {

	private String driver_Id;
	private String cell_Phone;
	private String imei;
	
	public String getDriver_Id() {
		return driver_Id;
	}
	public void setDriver_Id(String driver_Id) {
		this.driver_Id = driver_Id;
	}
	public String getCell_Phone() {
		return cell_Phone;
	}
	public void setCell_Phone(String cell_Phone) {
		this.cell_Phone = cell_Phone;
	}
	public String getImei() {
		return imei;
	}
	public void setImei(String imei) {
		this.imei = imei;
	}
}
