package com.letvyidao.inter;

public class ReUserInfo {

	private String cell_Phone;
	private String user_Id;
	private String device_Id;
	
	
	public String getCell_Phone() {
		return cell_Phone;
	}
	public void setCell_Phone(String cell_Phone) {
		this.cell_Phone = cell_Phone;
	}
	public String getUser_Id() {
		return user_Id;
	}
	public void setUser_Id(String user_Id) {
		this.user_Id = user_Id;
	}
	public String getDevice_Id() {
		return device_Id;
	}
	public void setDevice_Id(String device_Id) {
		this.device_Id = device_Id;
	}
}
