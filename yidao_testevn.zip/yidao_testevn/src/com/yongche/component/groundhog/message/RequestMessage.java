package com.yongche.component.groundhog.message;

abstract public class RequestMessage extends GroundhogMessage {
}
