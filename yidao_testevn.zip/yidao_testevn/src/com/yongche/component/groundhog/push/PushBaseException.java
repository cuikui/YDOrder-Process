package com.yongche.component.groundhog.push;

public class PushBaseException extends Exception {

    private static final long serialVersionUID = 6859326920469362133L;

    public PushBaseException() {
        // TODO Auto-generated constructor stub
    }

    public PushBaseException(String detailMessage) {
        super(detailMessage);
        // TODO Auto-generated constructor stub
    }

    public PushBaseException(Throwable throwable) {
        super(throwable);
        // TODO Auto-generated constructor stub
    }

    public PushBaseException(String detailMessage, Throwable throwable) {
        super(detailMessage, throwable);
        // TODO Auto-generated constructor stub
    }

}
