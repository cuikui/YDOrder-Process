package com.yongche.component.groundhog.push;

public class PushConnectionException extends PushBaseException {

    private static final long serialVersionUID = -2883429416738386363L;

    public PushConnectionException() {
        // TODO Auto-generated constructor stub
    }

    public PushConnectionException(String detailMessage) {
        super(detailMessage);
        // TODO Auto-generated constructor stub
    }

    public PushConnectionException(Throwable throwable) {
        super(throwable);
        // TODO Auto-generated constructor stub
    }

    public PushConnectionException(String detailMessage, Throwable throwable) {
        super(detailMessage, throwable);
        // TODO Auto-generated constructor stub
    }

}
