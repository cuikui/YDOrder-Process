package com.yongche.component.groundhog;

public interface ILoginStatusListener {
    
    public void onLoginFailed();
    
}